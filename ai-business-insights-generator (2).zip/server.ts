import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Middleware for JSON parsing
  app.use(express.json());

  // API routes
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", message: "AI Business Insights API is running" });
  });

  // Mock data endpoint
  app.get("/api/mock-data", (req, res) => {
    const mockData = [
      { date: "2024-01-01", revenue: 4000, expenses: 2400, sales: 240 },
      { date: "2024-02-01", revenue: 3000, expenses: 1398, sales: 210 },
      { date: "2024-03-01", revenue: 2000, expenses: 9800, sales: 229 },
      { date: "2024-04-01", revenue: 2780, expenses: 3908, sales: 200 },
      { date: "2024-05-01", revenue: 1890, expenses: 4800, sales: 218 },
      { date: "2024-06-01", revenue: 2390, expenses: 3800, sales: 250 },
      { date: "2024-07-01", revenue: 3490, expenses: 4300, sales: 210 },
    ];
    res.json(mockData);
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
