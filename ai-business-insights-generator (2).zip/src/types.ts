export interface BusinessData {
  [key: string]: any;
}

export interface AnalysisResult {
  summary: {
    totalRevenue: number;
    totalExpenses: number;
    netProfit: number;
    growthRate: number;
    avgSales: number;
  };
  trends: {
    date: string;
    revenue: number;
    expenses: number;
    sales: number;
  }[];
  anomalies: string[];
  correlations: {
    factor1: string;
    factor2: string;
    coefficient: number;
  }[];
}

export interface AIInsight {
  title: string;
  description: string;
  type: "insight" | "recommendation" | "risk";
  impact: "high" | "medium" | "low";
}

export interface DashboardState {
  data: BusinessData[];
  analysis: AnalysisResult | null;
  insights: AIInsight[];
  loading: boolean;
  error: string | null;
}
