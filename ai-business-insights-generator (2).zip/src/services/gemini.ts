import { GoogleGenAI, Type } from "@google/genai";
import { AnalysisResult, AIInsight } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export async function generateInsights(analysis: AnalysisResult): Promise<AIInsight[]> {
  const prompt = `
    Analyze the following business data summary and provide actionable insights, recommendations, and risk alerts.
    
    Data Summary:
    - Total Revenue: ${analysis.summary.totalRevenue}
    - Total Expenses: ${analysis.summary.totalExpenses}
    - Net Profit: ${analysis.summary.netProfit}
    - Growth Rate: ${analysis.summary.growthRate}%
    - Average Sales: ${analysis.summary.avgSales}
    
    Anomalies Detected: ${analysis.anomalies.join(", ") || "None"}
    
    Please return a JSON array of objects with the following structure:
    {
      "title": "Short descriptive title",
      "description": "Detailed explanation and actionable advice",
      "type": "insight" | "recommendation" | "risk",
      "impact": "high" | "medium" | "low"
    }
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              description: { type: Type.STRING },
              type: { type: Type.STRING, enum: ["insight", "recommendation", "risk"] },
              impact: { type: Type.STRING, enum: ["high", "medium", "low"] }
            },
            required: ["title", "description", "type", "impact"]
          }
        }
      }
    });

    const text = response.text;
    if (!text) return [];
    return JSON.parse(text);
  } catch (error) {
    console.error("Error generating insights:", error);
    return [
      {
        title: "AI Analysis Unavailable",
        description: "We couldn't generate AI insights at this moment. Please check your data and try again.",
        type: "risk",
        impact: "medium"
      }
    ];
  }
}
