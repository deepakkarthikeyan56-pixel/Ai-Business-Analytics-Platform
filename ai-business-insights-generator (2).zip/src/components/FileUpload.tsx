import React, { useRef } from "react";
import { Upload, FileSpreadsheet, AlertCircle } from "lucide-react";
import Papa from "papaparse";
import { BusinessData } from "../types";

interface FileUploadProps {
  onDataLoaded: (data: BusinessData[]) => void;
  onMockData: () => void;
}

export function FileUpload({ onDataLoaded, onMockData }: FileUploadProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    Papa.parse(file, {
      header: true,
      dynamicTyping: true,
      complete: (results) => {
        onDataLoaded(results.data as BusinessData[]);
      },
      error: (error) => {
        console.error("Error parsing CSV:", error);
      },
    });
  };

  return (
    <div className="max-w-2xl mx-auto py-12">
      <div className="bg-white rounded-3xl border border-gray-200 p-12 text-center shadow-sm">
        <div className="w-20 h-20 bg-indigo-50 rounded-full flex items-center justify-center mx-auto mb-6">
          <Upload className="text-indigo-600 w-10 h-10" />
        </div>
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Upload your business data</h2>
        <p className="text-gray-500 mb-8 max-w-md mx-auto">
          Upload a CSV or Excel file containing your sales, revenue, and expense data for automated analysis.
        </p>

        <div className="flex flex-col gap-4 items-center">
          <button
            onClick={() => fileInputRef.current?.click()}
            className="bg-indigo-600 text-white px-8 py-3 rounded-xl font-semibold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200 flex items-center gap-2"
          >
            <FileSpreadsheet className="w-5 h-5" />
            Select CSV File
          </button>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept=".csv"
            className="hidden"
          />

          <div className="flex items-center gap-4 w-full my-4">
            <div className="h-px bg-gray-200 flex-1"></div>
            <span className="text-gray-400 text-sm font-medium">OR</span>
            <div className="h-px bg-gray-200 flex-1"></div>
          </div>

          <button
            onClick={onMockData}
            className="text-indigo-600 font-medium hover:underline flex items-center gap-2"
          >
            Use sample business data
          </button>
        </div>

        <div className="mt-12 p-4 bg-amber-50 rounded-2xl border border-amber-100 flex gap-3 text-left">
          <AlertCircle className="text-amber-600 w-5 h-5 flex-shrink-0 mt-0.5" />
          <div className="text-sm text-amber-800">
            <p className="font-semibold mb-1">Data Requirements</p>
            <p className="opacity-80">Ensure your file has columns like 'date', 'revenue', 'expenses', and 'sales' for the best analysis results.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
