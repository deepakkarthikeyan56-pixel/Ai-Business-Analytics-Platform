import React from "react";
import { Download, FileText, Printer } from "lucide-react";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";
import { AnalysisResult, AIInsight } from "../types";
import { formatCurrency, cn } from "../lib/utils";

interface ReportProps {
  analysis: AnalysisResult;
  insights: AIInsight[];
}

export function Report({ analysis, insights }: ReportProps) {
  const downloadPDF = async () => {
    const element = document.getElementById("report-content");
    if (!element) return;

    const canvas = await html2canvas(element, { scale: 2 });
    const imgData = canvas.toDataURL("image/png");
    const pdf = new jsPDF("p", "mm", "a4");
    const imgProps = pdf.getImageProperties(imgData);
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
    
    pdf.addImage(imgData, "PNG", 0, 0, pdfWidth, pdfHeight);
    pdf.save("business-insights-report.pdf");
  };

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Business Report</h2>
          <p className="text-gray-500">Generate and download a comprehensive analysis report.</p>
        </div>
        <div className="flex gap-3">
          <button className="flex items-center gap-2 px-4 py-2 border border-gray-200 rounded-xl text-sm font-medium text-gray-600 hover:bg-gray-50 transition-all">
            <Printer className="w-4 h-4" />
            Print
          </button>
          <button 
            onClick={downloadPDF}
            className="flex items-center gap-2 px-6 py-2 bg-indigo-600 text-white rounded-xl text-sm font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100"
          >
            <Download className="w-4 h-4" />
            Download PDF
          </button>
        </div>
      </div>

      <div id="report-content" className="bg-white p-12 rounded-3xl border border-gray-100 shadow-sm max-w-4xl mx-auto">
        <div className="flex justify-between items-start border-b border-gray-100 pb-8 mb-8">
          <div>
            <h1 className="text-3xl font-black text-indigo-600 mb-2">InsightGen</h1>
            <p className="text-sm text-gray-500 font-medium uppercase tracking-widest">Business Analytics Report</p>
          </div>
          <div className="text-right">
            <p className="text-sm font-bold text-gray-900">Date: {new Date().toLocaleDateString()}</p>
            <p className="text-sm text-gray-500">Report ID: #IG-{Math.floor(Math.random() * 10000)}</p>
          </div>
        </div>

        <section className="mb-12">
          <h3 className="text-lg font-bold text-gray-900 mb-4 border-l-4 border-indigo-600 pl-3">Executive Summary</h3>
          <p className="text-gray-600 leading-relaxed">
            This report provides a detailed analysis of business performance based on the provided dataset. 
            Overall, the business has generated a total revenue of <span className="font-bold text-gray-900">{formatCurrency(analysis.summary.totalRevenue)}</span> 
            with a net profit of <span className="font-bold text-gray-900">{formatCurrency(analysis.summary.netProfit)}</span>. 
            The growth rate is currently at <span className="font-bold text-indigo-600">{analysis.summary.growthRate}%</span>.
          </p>
        </section>

        <section className="mb-12">
          <h3 className="text-lg font-bold text-gray-900 mb-6 border-l-4 border-indigo-600 pl-3">Key Performance Indicators</h3>
          <div className="grid grid-cols-2 gap-6">
            <div className="p-6 bg-gray-50 rounded-2xl">
              <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1">Total Revenue</p>
              <p className="text-2xl font-bold text-gray-900">{formatCurrency(analysis.summary.totalRevenue)}</p>
            </div>
            <div className="p-6 bg-gray-50 rounded-2xl">
              <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1">Total Expenses</p>
              <p className="text-2xl font-bold text-gray-900">{formatCurrency(analysis.summary.totalExpenses)}</p>
            </div>
            <div className="p-6 bg-gray-50 rounded-2xl">
              <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1">Net Profit</p>
              <p className="text-2xl font-bold text-gray-900">{formatCurrency(analysis.summary.netProfit)}</p>
            </div>
            <div className="p-6 bg-gray-50 rounded-2xl">
              <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1">Growth Rate</p>
              <p className="text-2xl font-bold text-gray-900">{analysis.summary.growthRate}%</p>
            </div>
          </div>
        </section>

        <section>
          <h3 className="text-lg font-bold text-gray-900 mb-6 border-l-4 border-indigo-600 pl-3">AI-Generated Insights</h3>
          <div className="space-y-6">
            {insights.map((insight, idx) => (
              <div key={idx} className="pb-6 border-b border-gray-50 last:border-0">
                <div className="flex items-center gap-2 mb-2">
                  <span className={cn(
                    "w-2 h-2 rounded-full",
                    insight.type === "risk" ? "bg-rose-500" : insight.type === "recommendation" ? "bg-emerald-500" : "bg-indigo-500"
                  )}></span>
                  <h4 className="font-bold text-gray-900">{insight.title}</h4>
                </div>
                <p className="text-gray-600 text-sm leading-relaxed pl-4">{insight.description}</p>
              </div>
            ))}
          </div>
        </section>

        <div className="mt-12 pt-8 border-t border-gray-100 text-center">
          <p className="text-xs text-gray-400 font-medium">Generated by InsightGen AI Analytics Engine</p>
        </div>
      </div>
    </div>
  );
}
