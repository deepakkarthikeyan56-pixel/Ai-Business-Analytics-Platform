import React from "react";
import { Lightbulb, TrendingUp, ShieldAlert, CheckCircle2, ArrowRight } from "lucide-react";
import { AIInsight } from "../types";
import { cn } from "../lib/utils";
import { motion } from "motion/react";

interface InsightsProps {
  insights: AIInsight[];
}

export function Insights({ insights }: InsightsProps) {
  const getIcon = (type: AIInsight["type"]) => {
    switch (type) {
      case "insight": return Lightbulb;
      case "recommendation": return CheckCircle2;
      case "risk": return ShieldAlert;
      default: return Lightbulb;
    }
  };

  const getColor = (type: AIInsight["type"]) => {
    switch (type) {
      case "insight": return "bg-indigo-50 text-indigo-600 border-indigo-100";
      case "recommendation": return "bg-emerald-50 text-emerald-600 border-emerald-100";
      case "risk": return "bg-rose-50 text-rose-600 border-rose-100";
      default: return "bg-gray-50 text-gray-600 border-gray-100";
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {insights.map((insight, idx) => {
        const Icon = getIcon(insight.type);
        return (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            key={idx}
            className={cn(
              "p-8 rounded-3xl border flex flex-col h-full transition-all hover:shadow-lg",
              getColor(insight.type)
            )}
          >
            <div className="flex justify-between items-start mb-6">
              <div className={cn("p-3 rounded-2xl bg-white/50")}>
                <Icon className="w-6 h-6" />
              </div>
              <span className={cn(
                "text-[10px] font-bold uppercase tracking-widest px-3 py-1 rounded-full bg-white/50",
                insight.impact === "high" ? "text-rose-600" : insight.impact === "medium" ? "text-amber-600" : "text-emerald-600"
              )}>
                {insight.impact} Impact
              </span>
            </div>
            
            <h3 className="text-xl font-bold mb-3 text-gray-900">{insight.title}</h3>
            <p className="text-gray-600 leading-relaxed mb-8 flex-1">
              {insight.description}
            </p>
            
            <button className="flex items-center gap-2 text-sm font-bold group">
              Learn more
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </button>
          </motion.div>
        );
      })}
    </div>
  );
}
