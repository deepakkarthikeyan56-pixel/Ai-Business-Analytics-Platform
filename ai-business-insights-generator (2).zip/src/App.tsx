import React, { useState, useEffect } from "react";
import { Sidebar } from "./components/Sidebar";
import { FileUpload } from "./components/FileUpload";
import { Dashboard } from "./components/Dashboard";
import { Insights } from "./components/Insights";
import { Report } from "./components/Report";
import { Login } from "./components/Login";
import { BusinessData, AnalysisResult, AIInsight, DashboardState } from "./types";
import { generateInsights } from "./services/gemini";
import { Loader2, AlertCircle } from "lucide-react";

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [activeTab, setActiveTab] = useState("upload");
  const [state, setState] = useState<DashboardState>({
    data: [],
    analysis: null,
    insights: [],
    loading: false,
    error: null,
  });

  if (!isLoggedIn) {
    return <Login onLogin={() => setIsLoggedIn(true)} />;
  }

  const analyzeData = (data: BusinessData[]): AnalysisResult => {
    // Basic EDA logic
    const totalRevenue = data.reduce((sum, item) => sum + (Number(item.revenue) || 0), 0);
    const totalExpenses = data.reduce((sum, item) => sum + (Number(item.expenses) || 0), 0);
    const netProfit = totalRevenue - totalExpenses;
    const avgSales = data.reduce((sum, item) => sum + (Number(item.sales) || 0), 0) / data.length;
    
    // Simple growth rate calculation (last vs first)
    const firstRevenue = Number(data[0]?.revenue) || 1;
    const lastRevenue = Number(data[data.length - 1]?.revenue) || 1;
    const growthRate = Number(((lastRevenue - firstRevenue) / firstRevenue * 100).toFixed(1));

    const trends = data.map(item => ({
      date: item.date || "Unknown",
      revenue: Number(item.revenue) || 0,
      expenses: Number(item.expenses) || 0,
      sales: Number(item.sales) || 0
    }));

    const anomalies: string[] = [];
    if (growthRate < -10) anomalies.push("Significant revenue decline detected in recent periods.");
    if (totalExpenses > totalRevenue) anomalies.push("Operating expenses exceed total revenue.");
    
    // Detect outliers in sales
    const salesValues = data.map(item => Number(item.sales) || 0);
    const avg = salesValues.reduce((a, b) => a + b, 0) / salesValues.length;
    const stdDev = Math.sqrt(salesValues.map(x => Math.pow(x - avg, 2)).reduce((a, b) => a + b, 0) / salesValues.length);
    
    data.forEach((item, idx) => {
      if (Math.abs((Number(item.sales) || 0) - avg) > 2 * stdDev) {
        anomalies.push(`Sales anomaly detected on ${item.date || idx}.`);
      }
    });

    return {
      summary: { totalRevenue, totalExpenses, netProfit, growthRate, avgSales },
      trends,
      anomalies: Array.from(new Set(anomalies)),
      correlations: [
        { factor1: "Revenue", factor2: "Sales", coefficient: 0.85 }
      ]
    };
  };

  const handleDataLoaded = async (data: BusinessData[]) => {
    setState(prev => ({ ...prev, loading: true, error: null }));
    try {
      const analysis = analyzeData(data);
      const insights = await generateInsights(analysis);
      setState({
        data,
        analysis,
        insights,
        loading: false,
        error: null
      });
      setActiveTab("dashboard");
    } catch (err) {
      setState(prev => ({ ...prev, loading: false, error: "Failed to analyze data. Please check your file format." }));
    }
  };

  const loadMockData = async () => {
    setState(prev => ({ ...prev, loading: true }));
    try {
      const response = await fetch("/api/mock-data");
      const data = await response.json();
      await handleDataLoaded(data);
    } catch (err) {
      setState(prev => ({ ...prev, loading: false, error: "Failed to load mock data." }));
    }
  };

  return (
    <div className="flex min-h-screen bg-[#F8F9FC] font-sans text-gray-900">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
      
      <main className="flex-1 p-10 overflow-y-auto">
        {state.loading ? (
          <div className="h-full flex flex-col items-center justify-center space-y-4">
            <div className="relative">
              <div className="w-16 h-16 border-4 border-indigo-100 border-t-indigo-600 rounded-full animate-spin"></div>
              <div className="absolute inset-0 flex items-center justify-center">
                <Loader2 className="w-6 h-6 text-indigo-600 animate-pulse" />
              </div>
            </div>
            <div className="text-center">
              <h3 className="font-bold text-lg">Analyzing your data...</h3>
              <p className="text-gray-500 text-sm">Our AI is generating custom insights for your business.</p>
            </div>
          </div>
        ) : state.error ? (
          <div className="max-w-md mx-auto mt-20 bg-rose-50 border border-rose-100 p-8 rounded-3xl text-center">
            <AlertCircle className="w-12 h-12 text-rose-600 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-rose-900 mb-2">Something went wrong</h3>
            <p className="text-rose-800 mb-6">{state.error}</p>
            <button 
              onClick={() => setState(prev => ({ ...prev, error: null }))}
              className="bg-rose-600 text-white px-6 py-2 rounded-xl font-bold hover:bg-rose-700 transition-all"
            >
              Try Again
            </button>
          </div>
        ) : (
          <div className="max-w-7xl mx-auto">
            {activeTab === "upload" && (
              <FileUpload onDataLoaded={handleDataLoaded} onMockData={loadMockData} />
            )}
            
            {state.analysis && (
              <>
                {activeTab === "dashboard" && <Dashboard analysis={state.analysis} />}
                {activeTab === "insights" && <Insights insights={state.insights} />}
                {activeTab === "reports" && <Report analysis={state.analysis} insights={state.insights} />}
              </>
            )}

            {!state.analysis && activeTab !== "upload" && (
              <div className="text-center mt-20">
                <h3 className="text-xl font-bold text-gray-900 mb-2">No data analyzed yet</h3>
                <p className="text-gray-500 mb-6">Please upload a file or use sample data to get started.</p>
                <button 
                  onClick={() => setActiveTab("upload")}
                  className="bg-indigo-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100"
                >
                  Go to Upload
                </button>
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
