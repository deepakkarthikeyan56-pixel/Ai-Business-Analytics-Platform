# AI Business Insights Generator

A full-stack AI-powered Business Analytics Web Application that automatically analyzes business data and generates actionable insights.

## Features
- **Data Upload**: Upload CSV files for analysis.
- **Automated EDA**: Generates summary statistics, trends, and detects anomalies.
- **AI Insights**: Powered by Gemini 3 Flash to provide human-readable recommendations and risk alerts.
- **Interactive Dashboard**: Visualizations using Recharts.
- **Report Generation**: Downloadable PDF reports.
- **Smart Alerts**: Real-time warnings for business performance.

## Tech Stack
- **Frontend**: React, Tailwind CSS, Recharts, Motion, Lucide React.
- **Backend**: Node.js, Express.
- **AI**: Google Gemini API.

## How to Run Locally
1. Clone the repository.
2. Install dependencies: `npm install`.
3. Set your `GEMINI_API_KEY` in a `.env` file.
4. Start the development server: `npm run dev`.
5. Open `http://localhost:3000` in your browser.

## Sample Data
You can use the "Use sample business data" button in the app to test with pre-loaded mock data.
